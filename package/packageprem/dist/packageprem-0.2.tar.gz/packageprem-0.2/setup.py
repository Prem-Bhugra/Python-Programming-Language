from setuptools import setup
setup(name = "packageprem",
version = 0.2,
description = "This is a package built by prem bhugra",
Long_description = "This is a very long description",
author = "Prem Bhugra",
packages = ["packageprem"],
install_requires = [])