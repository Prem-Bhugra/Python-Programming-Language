def func(number):
    print("This is a function")
    return number
print(func(2))
print("The function has been executed")